package com.party.partymangement.dao;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.party.partymangement.mapper.ScheduleMapper;
import com.party.partymangement.mapper.UserContactMapper;
import com.party.partymangement.mapper.VenueMapper;
import com.party.partymangement.model.ScheduleModel;
import com.party.partymangement.model.UserContactModel;
import com.party.partymangement.model.VenueModel;

@Repository
public class UserContactDao {

	
	private final String INSERTUSERCONTACT = "insert into contacts (userId,name,contactNumber,email) values(?,?,?,?);";
	private final String SELECTUSERCONTACT = "select * from contacts;";
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public boolean insertUserContact(UserContactModel userContact) {
		if (jdbcTemplate.update(INSERTUSERCONTACT,"Sath22", userContact.getName(), userContact.getContactNumber(), userContact.getEmail()) != 0) {
			return true;
		}
		return false;
	}
		public List<UserContactModel> getAllUserContactList() {
			return this.jdbcTemplate.query(SELECTUSERCONTACT, new UserContactMapper());
		}
		
	
	
}
