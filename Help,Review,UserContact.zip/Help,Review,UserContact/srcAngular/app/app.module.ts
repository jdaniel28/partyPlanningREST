import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { VenueComponent } from './venue/venue.component';
import { appRoutes } from 'src/app/routerConfig';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DisplayVenueComponent } from './display-venue/display-venue.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { DisplayScheduleComponent } from './display-schedule/display-schedule.component';
import { HelpComponent } from './help/help.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReviewComponent } from './review/review.component';
import { NgxStarRatingModule } from 'ngx-star-rating';
import { UserContactlistComponent } from './user-contactlist/user-contactlist.component';
import { DiaplayUsercontactlistComponent } from './diaplay-usercontactlist/diaplay-usercontactlist.component';

@NgModule({
  declarations: [
    AppComponent,
    VenueComponent,
    DisplayVenueComponent,
    ScheduleComponent,
    DisplayScheduleComponent,
    HelpComponent,
    ReviewComponent,
    UserContactlistComponent,
    DiaplayUsercontactlistComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    NgxStarRatingModule
 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
