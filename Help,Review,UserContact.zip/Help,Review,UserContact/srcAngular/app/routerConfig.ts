import { Routes } from '@angular/router';
import { VenueComponent } from './venue/venue.component';




export const appRoutes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'venue', component: VenueComponent },
];