export interface UserContact {
    contactId : string
    userId: string
    name: string
    contactNumber : string
    email : string 

}