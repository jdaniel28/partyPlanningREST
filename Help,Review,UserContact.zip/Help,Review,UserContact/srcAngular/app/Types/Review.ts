export interface Review {
    feedbackId : string
    userId:string
    venueId: string
    ans1: string
    ans2: string
    ans3: string
    rating: string
}