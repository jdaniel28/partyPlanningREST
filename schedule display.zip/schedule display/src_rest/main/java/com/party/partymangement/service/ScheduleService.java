package com.party.partymangement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.party.partymangement.dao.ScheduleDao;
import com.party.partymangement.dao.VenueDao;
import com.party.partymangement.model.RegisterModel;
import com.party.partymangement.model.ScheduleModel;
import com.party.partymangement.model.VenueModel;

@Service
public class ScheduleService {

	
	@Autowired
	private ScheduleDao scheduleDao;
	
	public boolean postSchedule(ScheduleModel schedule) {
		return scheduleDao.insertSchedule(schedule);
	}
	

	public List<ScheduleModel> getAllSchedules() {
		return this.scheduleDao.getAllSchedules();
	}
	
	
}
