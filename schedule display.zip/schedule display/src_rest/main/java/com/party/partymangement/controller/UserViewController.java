package com.party.partymangement.controller;

public class UserViewController {

}
