package com.cts.party;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartyPlanningApplicationTests {

	@Test
	void contextLoads() {
	}

}
