import { Component, OnInit } from '@angular/core';
import { Venue } from '../Types/Venue';

@Component({
  selector: 'app-display-venue',
  templateUrl: './display-venue.component.html',
  styleUrls: ['./display-venue.component.css']
})
export class DisplayVenueComponent implements OnInit {




  venue: Venue[] = [
    {
      venueId: "1",
      venueName: "Hardik",
      venueType: "hardik@gmail.com",
    },
    {
      venueId: "12",
      venueName: "Hardik",
      venueType: "hardik@gmail.com",
    },
    {
      venueId: "13",
      venueName: "Hardik",
      venueType: "hardik@gmail.com",
    },
    {
      venueId: "14",
      venueName: "Hardik",
      venueType: "hardik@gmail.com",
    },
    {
      venueId: "15",
      venueName: "Hardik",
      venueType: "hardik@gmail.com",
    },
    ]

  constructor() { }

  ngOnInit(): void {
  }
 
 

}
