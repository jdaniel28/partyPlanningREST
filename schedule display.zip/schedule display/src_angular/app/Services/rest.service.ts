
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Schedule } from '../Types/Schedule';
import { Venue } from '../Types/Venue';

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(private http: HttpClient) {
  }

  root_url = "http://localhost:9090/";

 /* getUser(userId: string) {
    return this.http.get<User>(this.root_url + "User/" + userId);
  }
  */

  postVenue(venue: Venue) {
    const headers = { 'content-type': 'application/json' }
    const body = JSON.stringify(venue);
    return this.http.post<Venue>(this.root_url + "Venue", body, { 'headers': headers, 'observe': 'response' });
  }

  
  postSchedule(schedule : Schedule) {
    const headers = { 'content-type': 'application/json' }
    const body = JSON.stringify(schedule);
    return this.http.post<Schedule>(this.root_url + "Schedule", body, { 'headers': headers, 'observe': 'response' });
  }




}
