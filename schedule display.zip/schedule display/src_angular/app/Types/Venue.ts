export interface Venue {
    venueId: string
    venueName: string
    venueType: string
}